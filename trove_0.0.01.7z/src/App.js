import logo from './logo.svg';

import { AudioPlayer } from './components/audioplayer/AudioPlayer';

import NoSong from './NoSong.png';

import HeartIcon from "./assets/Trv_icons/Trv_likeIcon_outline.svg";

import { BsPlay, BsPause } from "react-icons/bs"

import './App.css';

const songName = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";

function App() {
  return (


    <div className="text-gray-500 font-sans bg-gray-700" style={{ height: '3000px' }}>
      {/* Style Updating: 
          npx tailwindcss build -i src/index.css -o src/styles.css --watch

          Running TestBuild:
          npm run start
      */}
      <div className="py-2 pt-2 w-full">
        {/*container*/}
        <div className="md:grid-cols-3 grid-rows-3" style={{ width: "100%" }}>
          {/*header*/}
          <div className="md:col-span-1  md:flex md:justify-end">
            <nav className="text-right ">
              <div className="flex justify-between">
                <h1 className="font-bold uppercase p-4 border-b border-gray-100">
                  <a href="/">TITLE</a>
                </h1>
                <div className="px-4 cursor-pointer md:hidden" id="burger">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-6 h-6">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                  </svg>
                </div>
              </div>
              <ul className="test-sm mt-6 hidden md:block" id="menu">
                <li className="text-gray-700 font-bold py-1">
                  <a className="px-4 flex justify-end border-r-4 border-blue">
                    <img src="img/rupert.png" alt="" className="ml-3 h-7 mr-3 object-cover" />
                    <span>Home</span>
                  </a>
                </li>
                <li className="py-1 border-r-4 border-white">
                  <a >
                    <span>About</span>
                  </a>
                </li>
                <li className="py-1 border-r-4 border-white">
                  <a >
                    <span>Contact</span>
                  </a>
                </li>
              </ul>
            </nav>
          </div>
        </div>{/*Header End*/}
      </div>
      {/*Body*/}
      <main className="px-16 py-6 bg-gray-900 row-span-1 md:col-span-2">
        {/*Login / Signup btns*/}
        <div className="font-bold flex justify-center md:justify-end">
          <a className="btn px-2 border-yellow-600 md:border-2">Log in</a>
          <a className="btn px-2 border-blue-500 md:border-2 ">Sign up</a>
        </div>
        {/*Body header*/}
        <header>
          <h2 className="text-grey-700 text-6xl font-semibold">Trove</h2>
          <h3 className="text-2xl font-semibold">Find Musical Treasures</h3>
        </header>



        {/* Content */}
        <div className="">

          <h4 className="font-bold mt-12 pb-2 border-b border-grey-600">Latest Recipes</h4>
          <div className="mt-8 grid lg:grid-cols-3 gap-10">
            {/*  Cards go here */}

            <div className="card">
              <img src="img/chicken.jpg" alt="" className="w-full h-32 sm:h-48 object-cover" />
              <div className="m-4">
                <span className="font-bold text-gray-800">Tangy Lemon Chicken</span>
                <span className="block text-gray-600">Recipe by: FootLuvr68419</span>
              </div>
              <div className="badge">
                <img className="w-3" src="./img/rupert.png" />
                <span className="ml-2">35 Mins</span>
              </div>
            </div>

            <div className="card">
              <img src="img/one-pot-meals-1666206954.jpeg" alt=""
                className="w-full h-32 sm:h-48 object-cover" />
              <div className="m-4">
                <span className="font-bold text-gray-800">Chicken Barf Suprise</span>
                <span className="block text-gray-600">Recipe by: ibelieveinDog3120</span>
              </div>
              <div className="badge">
                <img className="w-3" src="./img/IMG_20230118_224824.png" />
                <span className="ml-2">45 Mins</span>
              </div>
            </div>

            <div className="card phone_:bg-red-800 ">
              <img src="img/roast_turkey_dinner.jpg" alt="" className="w-full h-32 sm:h-48 object-cover" />
              <div className="m-4">
                <span className="title">Seasoned Roast Turkey</span>
                <span className="creator">Recipe by: IcantbelieveItsButter76</span>
              </div>
              <div className="badge">
                <img className="w-3 h-3.5" src="./img/IMG_20230118_224815.png" />
                <span className="ml-2">3 Hours</span>
              </div>
            </div>
          </div>

          <h4 className="font-bold mt-12 pb-2 border-b  border-grey-600">Latest Recipies</h4>

          <div className="mt-8">
            {/* cards go here */}
          </div>

          <div className="flex justify-center">
            <div className="btn text-black">Load More</div>
          </div>

        </div>

      </main>

      {/* Player Footer */}
      <footer className="
      bg-gradient-to-b from-transparent to-trv-Black text-white text-center 
      fixed inset-x-0 bottom-0 px-1/4 pb-0
      grid grid-flow-col grid-rows-2 grid-cols-3 gap-y-0.5
      w-full
      phone_sm:w-full
      m-0
      phone_sm:h-32
      phone_lg:h-40
      sm:h-38 md:h-28 lg:h-32
      md:grid-rows-1 items-center
      ">

        <div className="col-span-3  
                      bg-trv-sm-Play-bg
                      lg:border-2 rounded-t-sm rounded-b-lg 
                      shadow-lg
                      flex-row 
                      h-14 
                      m-auto
                      pb-2
                      phone_lg:h-24
                      w-11/12
                      ">
          {/* Using Flex! */}

          {/* Small */}
          <div className="flex-none h-1/6 font-body">
            {/* Song Progress and Range inp */}
                        <div className='flex -inset-y-1 relative'>
                            <input type="range"  className="w-full progressBar" defaultValue="0 " onChange />
                        </div>
          </div>
          <div className="flex flex-row h-5/6 mx-2">

            <div className="songBarItem w-10  flex ">
              {/* Like */}
              <svg width="17" height="14" viewBox="0 0 17 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 4.24359C0.0725035 3.90375 0.120839 3.55433 0.227178 3.22405C0.903877 1.13232 2.99681 -0.203137 5.19608 0.031405C6.3223 0.151069 7.27935 0.610581 8.08172 1.39558C8.21223 1.52482 8.3379 1.66363 8.49257 1.82158C8.65208 1.65405 8.78742 1.50567 8.93243 1.36207C11.2622 -0.897191 15.1194 -0.260576 16.5163 2.64009C17.3235 4.31539 17.0867 5.93804 16.0571 7.46017C15.5834 8.15901 14.9406 8.71425 14.3219 9.28386C12.6639 10.8108 10.9239 12.2515 9.17411 13.6779C8.96626 13.8455 8.76809 14.0369 8.47324 13.9938C8.31373 13.9699 8.13489 13.9316 8.01888 13.8359C5.85828 12.0792 3.69768 10.3178 1.71108 8.36962C1.00538 7.68035 0.454355 6.89536 0.193343 5.94283C0.111172 5.64606 0.0628363 5.33493 0 5.03338C0 4.77012 0 4.50685 0 4.24359ZM8.47807 12.309C8.53608 12.2659 8.57475 12.2372 8.61341 12.2085C9.78797 11.2176 10.977 10.246 12.1274 9.23599C12.9395 8.52758 13.7322 7.79045 14.4814 7.01981C15.2982 6.17737 15.6463 5.14825 15.3997 3.98512C14.9019 1.65884 12.0694 0.696739 10.2182 2.21408C9.91848 2.46299 9.6333 2.73582 9.37228 3.0278C8.72459 3.74579 8.2799 3.78887 7.59353 3.01823C7.40986 2.81241 7.20685 2.62573 7.00867 2.43427C6.2643 1.71628 5.37492 1.40037 4.33571 1.51046C2.46028 1.70192 1.16972 3.48731 1.57091 5.311C1.74975 6.11036 2.16544 6.76612 2.7648 7.31657C3.86685 8.32654 4.97374 9.33172 6.09996 10.3178C6.87816 10.9975 7.68054 11.6389 8.47807 12.309Z" fill="#777688" />
              </svg>
            </div>

            <div className=" songBarItem w-15 phone_lg:w-20 box-border p-1 flex overflow-hidden border-white border-y-1 border-x-1">
              {/* Album */}
              <img src={NoSong} className=" rounded-lg shadow-md w-0 phone_sm:w-10  phone_lg:w-20" />
            </div>

            <div className="songBarItem flex-auto inline-flex box-border justify-start px-1 ">
              {/* Song Info */}
              <div className=' h-fit overflow-ellipsis block w-full text-left'>
                <div className='text phone_lg:text-lg truncate w-32 phone_sm:w-32 phone_lg:w-56'>{songName}</div>
                <div className='pl-1 text-sm truncate w-32 phone_sm:w-28 phone_lg:w-52 '><a className='cursor-pointer'> Artist </a></div>
              </div>
            </div>

            <div className="songBarItem w-28 flex-row">
              
              <div className=" w-1/3 flex justify-end">
                <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12.3529 6.7323C12.3529 4.92033 12.3529 3.10406 12.3529 1.2921C12.3529 0.840184 12.0206 0.517387 11.5836 0.560427C11.4288 0.577643 11.2649 0.646506 11.1329 0.728281C8.73821 2.23036 6.34358 3.73674 3.95349 5.24743C3.48913 5.5401 3.02932 5.82847 2.56496 6.12113C2.04142 6.45254 2.04142 7.01636 2.56952 7.34776C5.43307 9.15542 8.30117 10.9588 11.1647 12.7621C11.6291 13.0548 12.1754 12.8956 12.3211 12.4264C12.3529 12.3274 12.3529 12.2155 12.3529 12.1079C12.3529 10.3175 12.3529 8.52274 12.3529 6.7323ZM10.8961 10.9459C8.65627 9.53417 6.44373 8.13969 4.21298 6.7366C6.44828 5.3249 8.66082 3.93042 10.8961 2.52303C10.8961 5.34212 10.8961 8.12678 10.8961 10.9459ZM0.00188065 2.77266C0.00188065 2.7081 0.00187969 2.64354 0.00643158 2.57898C0.024642 2.2691 0.247717 2.01086 0.55729 1.942C0.871415 1.87313 1.21286 2.00225 1.35399 2.2777C1.41772 2.40682 1.44959 2.56607 1.44959 2.7124C1.45414 5.39807 1.45414 8.07943 1.45414 10.7651C1.45414 10.8254 1.45414 10.8813 1.44959 10.9416C1.41772 11.2514 1.14457 11.514 0.816786 11.5398C0.347874 11.5785 0.0109844 11.2773 0.00643158 10.8124C0.00643158 9.461 0.00643158 8.10526 0.00643158 6.75382C0.00187969 5.42389 -0.0026722 4.09828 0.00188065 2.77266Z" fill="white" />
                </svg>
              </div>
              <div className="w-1/4 flex box-border justify-center text-xl">
                <BsPlay className="h-auto w-28"/>
              </div>
              <div className="w-1/3 flex justify-start">
                <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M0.647064 6.7323C0.647064 4.92033 0.647064 3.10406 0.647064 1.2921C0.647064 0.840184 0.9794 0.517387 1.41644 0.560427C1.57123 0.577643 1.73512 0.646506 1.86715 0.728281C4.26179 2.23036 6.65642 3.73674 9.04651 5.24743C9.51087 5.5401 9.97068 5.82847 10.435 6.12113C10.9586 6.45254 10.9586 7.01636 10.4305 7.34776C7.56693 9.15542 4.69883 10.9588 1.83528 12.7621C1.37092 13.0548 0.824613 12.8956 0.678932 12.4264C0.647064 12.3274 0.647064 12.2155 0.647064 12.1079C0.647064 10.3175 0.647064 8.52274 0.647064 6.7323ZM2.10388 10.9459C4.34373 9.53417 6.55627 8.13969 8.78702 6.7366C6.55172 5.3249 4.33918 3.93042 2.10388 2.52303C2.10388 5.34212 2.10388 8.12678 2.10388 10.9459ZM12.9981 2.77266C12.9981 2.7081 12.9981 2.64354 12.9936 2.57898C12.9754 2.2691 12.7523 2.01086 12.4427 1.942C12.1286 1.87313 11.7871 2.00225 11.646 2.2777C11.5823 2.40682 11.5504 2.56607 11.5504 2.7124C11.5459 5.39807 11.5459 8.07943 11.5459 10.7651C11.5459 10.8254 11.5459 10.8813 11.5504 10.9416C11.5823 11.2514 11.8554 11.514 12.1832 11.5398C12.6521 11.5785 12.989 11.2773 12.9936 10.8124C12.9936 9.461 12.9936 8.10526 12.9936 6.75382C12.9981 5.42389 13.0027 4.09828 12.9981 2.77266Z" fill="white" />
                </svg>
              </div>
              {/* Controls */}
            </div>
          </div>





          {/* Medium */}

          {/* Large */}

        </div>
        {/* <AudioPlayer/> */}
        {/* Audioplayer Component */}
        {/* <AudioPlayer/> */}



        <div className="mobileNav rounded row-span-1 col-span-3 h-12 m-auto md:hidden flex flex-row justify-around w-11/12">
          {/* Bot Nav */}
          <div className="bot_nav_item activeIcon">
              <svg className="mx-auto mt-2 mb-auto p-2/6 svgFill" width="20" height="20" viewBox="0 0 20 21" xmlns="http://www.w3.org/2000/svg">
              <path d="M0 13.6426C0 11.8681 0 10.0936 0 8.31905C0 7.6263 0.216715 7.02946 0.690455 6.54454C0.781171 6.45395 0.881963 6.36868 0.982759 6.29408C3.63873 4.27443 6.28965 2.24946 8.94562 0.229812C9.34377 -0.0739339 9.65119 -0.0792628 10.0544 0.229812C12.7053 2.24413 15.3512 4.26377 18.0021 6.28342C18.6724 6.78966 18.995 7.48242 18.995 8.3457C18.995 11.9001 18.9899 15.4598 19 19.0141C19 19.4937 18.6724 20.0053 18.0626 20C16.3491 19.9893 14.6355 19.9946 12.922 19.9946C12.6146 19.9946 12.3072 20 11.9947 19.9946C11.5966 19.984 11.2942 19.7442 11.1984 19.3605C11.1732 19.2592 11.1732 19.1527 11.1732 19.0461C11.1732 17.7565 11.1732 16.4669 11.1732 15.1773C11.1732 14.6018 11.0019 14.1009 10.5785 13.7279C10.0695 13.2696 9.47985 13.1523 8.84987 13.3868C8.22494 13.6213 7.85199 14.1009 7.73607 14.7936C7.71088 14.9375 7.70584 15.0867 7.70584 15.2306C7.70584 16.5202 7.7008 17.8098 7.70584 19.0994C7.70584 19.3445 7.63528 19.5577 7.47905 19.7335C7.32785 19.8987 7.14138 19.9786 6.92467 19.9946C6.86419 20 6.79868 20 6.7382 20C4.81804 20 2.89788 20 0.972681 20C0.902124 20 0.831569 20 0.766051 19.9946C0.337669 19.952 0.0403232 19.6269 0.00504471 19.174C4.92159e-06 19.11 0.00504471 19.0408 0.00504471 18.9768C4.92159e-06 17.1916 0 15.4171 0 13.6426ZM9.4748 1.87111C9.40424 1.9244 9.35385 1.9617 9.30345 1.999C7.49921 3.36852 5.69496 4.73804 3.89072 6.10757C3.22547 6.61381 2.56022 7.11472 1.89497 7.62097C1.68833 7.77551 1.56738 7.98333 1.56738 8.26043C1.56738 11.559 1.56738 14.8576 1.56738 18.1508C1.56738 18.1935 1.57745 18.2361 1.58249 18.2841C3.10955 18.2841 4.62653 18.2841 6.16366 18.2841C6.16366 18.2041 6.16366 18.1348 6.16366 18.0602C6.16366 17.1117 6.16366 16.1578 6.16366 15.2093C6.16366 14.9055 6.17878 14.5965 6.25438 14.2981C6.59709 12.9605 7.39841 12.0653 8.6634 11.7295C9.94854 11.3832 11.0674 11.7775 11.9594 12.8273C12.5188 13.4881 12.7759 14.2767 12.7759 15.1667C12.7708 16.1525 12.7759 17.133 12.7759 18.1189C12.7759 18.1881 12.7809 18.2574 12.7859 18.3267C14.3231 18.3267 15.8401 18.3267 17.3722 18.3267C17.3722 18.2414 17.3722 18.1615 17.3722 18.0816C17.3722 14.8629 17.3722 11.6443 17.3722 8.43096C17.3722 8.383 17.3722 8.34037 17.3722 8.29241C17.3772 8.06327 17.2814 7.88208 17.1252 7.73287C17.0748 7.68492 17.0143 7.64228 16.9589 7.59965C14.5751 5.77185 12.1862 3.94937 9.80239 2.12689C9.70159 2.0363 9.59576 1.95637 9.4748 1.87111Z"/>
              </svg>
              <p className="bot_nav_text activeText ">Home</p>
              </div>
          <div className="bot_nav_item inactiveIcon">
            <svg className="mx-auto mt-2 mb-auto p-2/6 svgFillInactive" width="21" height="20" viewBox="0 0 22  21"  xmlns="http://www.w3.org/2000/svg">
                <path d="M15.3327 15.959C13.0961 17.5878 10.6364 18.2306 7.9144 17.8187C5.54657 17.4568 3.59852 16.3584 2.09648 14.5861C-0.920703 11.0227 -0.651778 5.98022 2.71304 2.68516C5.99259 -0.52253 11.3251 -0.90945 15.0901 1.81147C17.189 3.32795 18.4418 5.34992 18.7763 7.83993C19.1108 10.3299 18.4155 12.5703 16.7954 14.5673C16.8676 14.6422 16.9397 14.7109 17.0053 14.7733C18.2056 15.9153 19.4125 17.0636 20.6194 18.2056C20.8489 18.4241 21.0064 18.6674 20.9998 18.9857C20.9932 19.3851 20.803 19.6909 20.4357 19.8781C20.0619 20.0653 19.6945 20.0341 19.3469 19.8032C19.2551 19.7408 19.1698 19.6597 19.0911 19.5848C17.8908 18.449 16.697 17.307 15.4967 16.1649C15.4442 16.1025 15.3983 16.0339 15.3327 15.959ZM16.7692 8.96949C16.7429 5.00044 13.4044 1.99869 9.46235 1.99245C5.40227 1.97997 2.11616 5.07532 2.10304 8.93828C2.08337 12.8075 5.36292 15.9528 9.42956 15.9465C13.4962 15.9403 16.7364 12.8574 16.7692 8.96949Z"/>
            </svg>
            <p className="bot_nav_text inactiveText">Search</p></div>
          <div className="bot_nav_item inactiveIcon svgFillInactive">
          <svg className="mx-auto mt-2 mb-auto p-2/6 svgFillInactive" width="24" height="20" viewBox="0 0 25 20" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M11.9628 19.9963C8.39 19.9963 4.81723 19.9963 1.25281 19.9963C1.15264 19.9963 1.04412 19.9963 0.943947 19.9963C0.443091 19.9629 0.050753 19.562 0.00901507 19.0693C0.000667477 19.0109 0.00901507 18.944 0.00901507 18.8856C0.00901507 14.2591 -0.0160272 9.63255 0.0173632 5.01438C0.0340584 2.8765 1.08585 1.33989 3.01415 0.421267C3.62352 0.128978 4.27464 0.00371161 4.95079 0.00371161C9.65883 0.00371161 14.3669 -0.00463951 19.0666 0.00371161C21.5375 0.0120627 23.6327 1.88271 23.9499 4.32959C23.9833 4.58012 24 4.83066 24 5.07284C24 9.66596 24 14.2591 24 18.8522C24 18.9942 23.9916 19.1445 23.9499 19.2864C23.833 19.6957 23.4825 19.9712 23.0567 19.9963C22.9566 20.0046 22.848 19.9963 22.7479 19.9963C19.15 19.9963 15.5606 19.9963 11.9628 19.9963ZM12.9979 11.8122C12.9979 12.2297 13.0062 12.6306 12.9979 13.0231C12.9812 13.4741 12.689 13.8332 12.2549 13.9584C11.8626 14.067 11.4285 13.9083 11.1864 13.5576C11.0529 13.3739 11.0028 13.1651 11.0028 12.9396C11.0028 12.5638 11.0028 12.188 11.0028 11.8122C10.5771 11.6368 10.2098 11.4113 9.89257 11.1023C9.56701 10.785 9.34997 10.4009 9.17467 10C7.87245 9.93319 2.25452 9.9666 2.02079 10.0334C2.02079 12.6807 2.02079 15.3197 2.02079 17.967C8.68217 17.967 15.3352 17.967 21.9715 17.967C21.9715 15.2946 21.9715 12.6473 21.9715 9.99165C19.5758 9.99165 17.2051 9.99165 14.8176 9.99165C14.4754 10.8602 13.8827 11.4614 12.9979 11.8122ZM9.16633 7.97903C9.70892 6.73471 10.6272 5.99981 12.0045 5.99981C13.3819 5.99981 14.3001 6.74306 14.826 7.97068C17.2218 7.97068 19.6008 7.97068 21.9966 7.97068C21.9966 7.88717 21.9966 7.82871 21.9966 7.77025C21.9966 6.85163 22.0049 5.94136 21.9966 5.02273C21.9799 3.3024 20.6777 1.99128 18.9581 1.99128C14.3168 1.98293 9.67553 1.98293 5.03427 1.99128C3.32301 1.99128 2.02079 3.31075 2.00409 5.02273C1.99574 5.92465 2.00409 6.83493 2.00409 7.73685C2.00409 7.81201 2.02079 7.89552 2.02913 7.97903C4.41655 7.97903 6.78726 7.97903 9.16633 7.97903ZM12.9979 8.98116C12.9895 8.43834 12.5471 7.98738 11.9962 7.98738C11.4369 7.98738 10.9861 8.44669 10.9945 9.00622C11.0028 9.54069 11.4703 9.99165 12.0129 9.9833C12.5638 9.9833 12.9979 9.52399 12.9979 8.98116Z"/>
          </svg>
            <p className="bot_nav_text inactiveText">Trove</p>
          </div>

        </div>

      </footer>


      <script src="/index2.js"></script>
    </div>
  );
}

export default App;
