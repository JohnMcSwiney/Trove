import logo from './logo.svg';

import { AudioPlayer } from './components/audioplayer/AudioPlayer';

import  NoSong  from './NoSong.png';

import HeartIcon from "./assets/Trv_icons/Trv_likeIcon_outline.svg";

import { BsPlay, BsPause } from "react-icons/bs"

import './App.css';

const songName = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";

function App() {
  return (

    
    <div className="text-gray-500 font-sans bg-gray-700" style={{ height: '3000px' }}>
      {/* Style Updating: 
          npx tailwindcss build -i src/index.css -o src/styles.css --watch

          Running TestBuild:
          npm run start
      */}
      <div className="p-2 w-full">
        {/*container*/}
        <div className="md:grid-cols-3 grid-rows-3" style={{ width: "100%" }}>
          {/*header*/}
          <div className="md:col-span-1  md:flex md:justify-end">
            <nav className="text-right ">
              <div className="flex justify-between">
                <h1 className="font-bold uppercase p-4 border-b border-gray-100">
                  <a href="/">TITLE</a>
                </h1>
                <div className="px-4 cursor-pointer md:hidden" id="burger">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-6 h-6">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                  </svg>
                </div>
              </div>
              <ul className="test-sm mt-6 hidden md:block" id="menu">
                <li className="text-gray-700 font-bold py-1">
                  <a className="px-4 flex justify-end border-r-4 border-blue">
                    <img src="img/rupert.png" alt="" className="ml-3 h-7 mr-3 object-cover" />
                    <span>Home</span>
                  </a>
                </li>
                <li className="py-1 border-r-4 border-white">
                  <a >
                    <span>About</span>
                  </a>
                </li>
                <li className="py-1 border-r-4 border-white">
                  <a >
                    <span>Contact</span>
                  </a>
                </li>
              </ul>
            </nav>
          </div>
        </div>{/*Header End*/}
      </div>
      {/*Body*/}
      <main className="px-16 py-6 bg-gray-900 row-span-1 md:col-span-2">
        {/*Login / Signup btns*/}
        <div className="font-bold flex justify-center md:justify-end">
          <a className="btn px-2 border-yellow-600 md:border-2">Log in</a>
          <a className="btn px-2 border-blue-500 md:border-2 ">Sign up</a>
        </div>
        {/*Body header*/}
        <header>
          <h2 className="text-grey-700 text-6xl font-semibold">Trove</h2>
          <h3 className="text-2xl font-semibold">Find Musical Treasures</h3>
        </header>

        

        {/* Content */}
        <div className="">

          <h4 className="font-bold mt-12 pb-2 border-b border-grey-600">Latest Recipes</h4>
          <div className="mt-8 grid lg:grid-cols-3 gap-10">
            {/*  Cards go here */}

            <div className="card">
              <img src="img/chicken.jpg" alt="" className="w-full h-32 sm:h-48 object-cover" />
              <div className="m-4">
                <span className="font-bold text-gray-800">Tangy Lemon Chicken</span>
                <span className="block text-gray-600">Recipe by: FootLuvr68419</span>
              </div>
              <div className="badge">
                <img className="w-3" src="./img/rupert.png" />
                <span className="ml-2">35 Mins</span>
              </div>
            </div>

            <div className="card">
              <img src="img/one-pot-meals-1666206954.jpeg" alt=""
                className="w-full h-32 sm:h-48 object-cover" />
              <div className="m-4">
                <span className="font-bold text-gray-800">Chicken Barf Suprise</span>
                <span className="block text-gray-600">Recipe by: ibelieveinDog3120</span>
              </div>
              <div className="badge">
                <img className="w-3" src="./img/IMG_20230118_224824.png" />
                <span className="ml-2">45 Mins</span>
              </div>
            </div>

            <div className="card phone_:bg-red-800 ">
              <img src="img/roast_turkey_dinner.jpg" alt="" className="w-full h-32 sm:h-48 object-cover" />
              <div className="m-4">
                <span className="title">Seasoned Roast Turkey</span>
                <span className="creator">Recipe by: IcantbelieveItsButter76</span>
              </div>
              <div className="badge">
                <img className="w-3 h-3.5" src="./img/IMG_20230118_224815.png" />
                <span className="ml-2">3 Hours</span>
              </div>
            </div>
          </div>

          <h4 className="font-bold mt-12 pb-2 border-b  border-grey-600">Latest Recipies</h4>

          <div className="mt-8">
            {/* cards go here */}
          </div>

          <div className="flex justify-center">
            <div className="btn text-black">Load More</div>
          </div>

        </div>

      </main>

      {/* Player Footer */}
      <footer className="
      bg-black text-3xl text-white text-center border-t-2 border-gray-600 
      fixed inset-x-0 bottom-0 p-1 pt-2
      grid grid-flow-col grid-rows-2 gap-y-0.5
      h-32
      phone_lg:h-44
      sm:h-38 md:h-28 lg:h-32
      md:grid-rows-1 items-center
      ">

        

        <div className="  
                    bg-Trv_D_Blue 
                      border-Trv_White border-2 rounded-b-lg 
                      flex-row overflow-hidden
                      h-16 
                      phone_lg:h-24
                      ">
                        {/* Using Flex! */}

                {/* Small */}
                <div className="bg-pink-400 flex-none h-1/6 font-body">
                          {/* Like */} 
                      </div>
                      <div className="flex flex-row h-5/6 mx-2">
                          <div className="songBarItem w-10  flex ">
                          <svg width="17" height="14" viewBox="0 0 17 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M0 4.24359C0.0725035 3.90375 0.120839 3.55433 0.227178 3.22405C0.903877 1.13232 2.99681 -0.203137 5.19608 0.031405C6.3223 0.151069 7.27935 0.610581 8.08172 1.39558C8.21223 1.52482 8.3379 1.66363 8.49257 1.82158C8.65208 1.65405 8.78742 1.50567 8.93243 1.36207C11.2622 -0.897191 15.1194 -0.260576 16.5163 2.64009C17.3235 4.31539 17.0867 5.93804 16.0571 7.46017C15.5834 8.15901 14.9406 8.71425 14.3219 9.28386C12.6639 10.8108 10.9239 12.2515 9.17411 13.6779C8.96626 13.8455 8.76809 14.0369 8.47324 13.9938C8.31373 13.9699 8.13489 13.9316 8.01888 13.8359C5.85828 12.0792 3.69768 10.3178 1.71108 8.36962C1.00538 7.68035 0.454355 6.89536 0.193343 5.94283C0.111172 5.64606 0.0628363 5.33493 0 5.03338C0 4.77012 0 4.50685 0 4.24359ZM8.47807 12.309C8.53608 12.2659 8.57475 12.2372 8.61341 12.2085C9.78797 11.2176 10.977 10.246 12.1274 9.23599C12.9395 8.52758 13.7322 7.79045 14.4814 7.01981C15.2982 6.17737 15.6463 5.14825 15.3997 3.98512C14.9019 1.65884 12.0694 0.696739 10.2182 2.21408C9.91848 2.46299 9.6333 2.73582 9.37228 3.0278C8.72459 3.74579 8.2799 3.78887 7.59353 3.01823C7.40986 2.81241 7.20685 2.62573 7.00867 2.43427C6.2643 1.71628 5.37492 1.40037 4.33571 1.51046C2.46028 1.70192 1.16972 3.48731 1.57091 5.311C1.74975 6.11036 2.16544 6.76612 2.7648 7.31657C3.86685 8.32654 4.97374 9.33172 6.09996 10.3178C6.87816 10.9975 7.68054 11.6389 8.47807 12.309Z" fill="#777688"/>
                            </svg>
                          </div>
                          <div className=" songBarItem w-15 phone_lg:w-20 box-border p-1 flex overflow-hidden border-white border-y-1 border-x-1">
                              {/* Album */}
                              <img src={NoSong} className=" rounded-lg shadow-md w-12 h-aut phone_lg:w-20  "  />
                          </div>
                          <div className="songBarItem flex-auto inline-flex box-border justify-start px-1 ">
                             {/* Song Info */}
                              <div className=' h-fit overflow-ellipsis block w-full text-left'>
                                <div className='text-lg truncate w-40 phone_lg:w-56'>{songName}</div>
                                <div className='pl-1 text-sm'><a className='cursor-pointer'> Artist </a></div>

                              </div>
                            
                             
                          </div>
                          <div className="songBarItem w-32 flex-row">
                              <div className="text-black w-1/3 flex justify-end">
                                <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M12.3529 6.7323C12.3529 4.92033 12.3529 3.10406 12.3529 1.2921C12.3529 0.840184 12.0206 0.517387 11.5836 0.560427C11.4288 0.577643 11.2649 0.646506 11.1329 0.728281C8.73821 2.23036 6.34358 3.73674 3.95349 5.24743C3.48913 5.5401 3.02932 5.82847 2.56496 6.12113C2.04142 6.45254 2.04142 7.01636 2.56952 7.34776C5.43307 9.15542 8.30117 10.9588 11.1647 12.7621C11.6291 13.0548 12.1754 12.8956 12.3211 12.4264C12.3529 12.3274 12.3529 12.2155 12.3529 12.1079C12.3529 10.3175 12.3529 8.52274 12.3529 6.7323ZM10.8961 10.9459C8.65627 9.53417 6.44373 8.13969 4.21298 6.7366C6.44828 5.3249 8.66082 3.93042 10.8961 2.52303C10.8961 5.34212 10.8961 8.12678 10.8961 10.9459ZM0.00188065 2.77266C0.00188065 2.7081 0.00187969 2.64354 0.00643158 2.57898C0.024642 2.2691 0.247717 2.01086 0.55729 1.942C0.871415 1.87313 1.21286 2.00225 1.35399 2.2777C1.41772 2.40682 1.44959 2.56607 1.44959 2.7124C1.45414 5.39807 1.45414 8.07943 1.45414 10.7651C1.45414 10.8254 1.45414 10.8813 1.44959 10.9416C1.41772 11.2514 1.14457 11.514 0.816786 11.5398C0.347874 11.5785 0.0109844 11.2773 0.00643158 10.8124C0.00643158 9.461 0.00643158 8.10526 0.00643158 6.75382C0.00187969 5.42389 -0.0026722 4.09828 0.00188065 2.77266Z" fill="white"/>
                                </svg>
                              </div>
                              <div className="w-1/4 flex box-border justify-center text-xl">
                                  <BsPlay/>
                              </div>
                              <div className="w-1/3 flex justify-start">
                                <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M0.647064 6.7323C0.647064 4.92033 0.647064 3.10406 0.647064 1.2921C0.647064 0.840184 0.9794 0.517387 1.41644 0.560427C1.57123 0.577643 1.73512 0.646506 1.86715 0.728281C4.26179 2.23036 6.65642 3.73674 9.04651 5.24743C9.51087 5.5401 9.97068 5.82847 10.435 6.12113C10.9586 6.45254 10.9586 7.01636 10.4305 7.34776C7.56693 9.15542 4.69883 10.9588 1.83528 12.7621C1.37092 13.0548 0.824613 12.8956 0.678932 12.4264C0.647064 12.3274 0.647064 12.2155 0.647064 12.1079C0.647064 10.3175 0.647064 8.52274 0.647064 6.7323ZM2.10388 10.9459C4.34373 9.53417 6.55627 8.13969 8.78702 6.7366C6.55172 5.3249 4.33918 3.93042 2.10388 2.52303C2.10388 5.34212 2.10388 8.12678 2.10388 10.9459ZM12.9981 2.77266C12.9981 2.7081 12.9981 2.64354 12.9936 2.57898C12.9754 2.2691 12.7523 2.01086 12.4427 1.942C12.1286 1.87313 11.7871 2.00225 11.646 2.2777C11.5823 2.40682 11.5504 2.56607 11.5504 2.7124C11.5459 5.39807 11.5459 8.07943 11.5459 10.7651C11.5459 10.8254 11.5459 10.8813 11.5504 10.9416C11.5823 11.2514 11.8554 11.514 12.1832 11.5398C12.6521 11.5785 12.989 11.2773 12.9936 10.8124C12.9936 9.461 12.9936 8.10526 12.9936 6.75382C12.9981 5.42389 13.0027 4.09828 12.9981 2.77266Z" fill="white"/>
                                </svg>
                              </div>
                              {/* Controls */}
                          </div>
                </div>
                      
                      


                    
                {/* Medium */}

                {/* Large */}

            </div>
        {/* <AudioPlayer/> */}
          {/* Audioplayer Component */}
          {/* <AudioPlayer/> */}

        

        <div className="rounded bg-blue-500 row-span-1 h-12 md:hidden flex-row flex justify-around ">
          <div className="bot_nav_item_active"><h1>1</h1>
            <p className="bot_nav_text">text</p></div>
          <div className="bot_nav_item"><h1>2</h1>
            <p className="bot_nav_text">text</p></div>
          <div className="bot_nav_item"><h1>3</h1>
            <p className="bot_nav_text">text</p></div>

            </div>

      </footer>


      <script src="/index2.js"></script>
    </div>
  );
}

export default App;
