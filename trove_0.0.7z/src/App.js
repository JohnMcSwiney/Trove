import logo from './logo.svg';
import './App.css';

function App() {
  return (

    
    <div className="text-gray-500 font-sans bg-gray-700" style={{ height: '3000px' }}>
      {/* Style Updating: 
          npx tailwindcss build -i src/index.css -o src/styles.css --watch

          Running TestBuild:
          npm run start
      */}
      <div className="p-2 w-full">
        {/*container*/}
        <div className="md:grid-cols-3 grid-rows-3" style={{ width: "100%" }}>
          {/*header*/}
          <div className="md:col-span-1  md:flex md:justify-end">
            <nav className="text-right ">
              <div className="flex justify-between">
                <h1 className="font-bold uppercase p-4 border-b border-gray-100">
                  <a href="/">TITLE</a>
                </h1>
                <div className="px-4 cursor-pointer md:hidden" id="burger">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-6 h-6">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                  </svg>
                </div>
              </div>
              <ul className="test-sm mt-6 hidden md:block" id="menu">
                <li className="text-gray-700 font-bold py-1">
                  <a className="px-4 flex justify-end border-r-4 border-blue">
                    <img src="img/rupert.png" alt="" className="ml-3 h-7 mr-3 object-cover" />
                    <span>Home</span>
                  </a>
                </li>
                <li className="py-1 border-r-4 border-white">
                  <a >
                    <span>About</span>
                  </a>
                </li>
                <li className="py-1 border-r-4 border-white">
                  <a >
                    <span>Contact</span>
                  </a>
                </li>
              </ul>
            </nav>
          </div>
        </div>{/*Header End*/}
      </div>
      {/*Body*/}
      <main className="px-16 py-6 bg-gray-900 row-span-1 md:col-span-2">
        {/*Login / Signup btns*/}
        <div className="font-bold flex justify-center md:justify-end">
          <a className="btn px-2 border-yellow-600 md:border-2">Log in</a>
          <a className="btn px-2 border-blue-500 md:border-2 ">Sign up</a>
        </div>
        {/*Body header*/}
        <header>
          <h2 className="text-grey-700 text-6xl font-semibold">Trove</h2>
          <h3 className="text-2xl font-semibold">Find Musical Treasures</h3>
        </header>

        {/* Content */}
        <div className="">

          <h4 className="font-bold mt-12 pb-2 border-b border-grey-600">Latest Recipes</h4>
          <div className="mt-8 grid lg:grid-cols-3 gap-10">
            {/*  Cards go here */}

            <div className="card">
              <img src="img/chicken.jpg" alt="" className="w-full h-32 sm:h-48 object-cover" />
              <div className="m-4">
                <span className="font-bold text-gray-800">Tangy Lemon Chicken</span>
                <span className="block text-gray-600">Recipe by: FootLuvr68419</span>
              </div>
              <div className="badge">
                <img className="w-3" src="./img/rupert.png" />
                <span className="ml-2">35 Mins</span>
              </div>
            </div>

            <div className="card">
              <img src="img/one-pot-meals-1666206954.jpeg" alt=""
                className="w-full h-32 sm:h-48 object-cover" />
              <div className="m-4">
                <span className="font-bold text-gray-800">Chicken Barf Suprise</span>
                <span className="block text-gray-600">Recipe by: ibelieveinDog3120</span>
              </div>
              <div className="badge">
                <img className="w-3" src="./img/IMG_20230118_224824.png" />
                <span className="ml-2">45 Mins</span>
              </div>
            </div>

            <div className="card phone_lg:bg-red-800 ">
              <img src="img/roast_turkey_dinner.jpg" alt="" className="w-full h-32 sm:h-48 object-cover" />
              <div className="m-4">
                <span className="title">Seasoned Roast Turkey</span>
                <span className="creator">Recipe by: IcantbelieveItsButter76</span>
              </div>
              <div className="badge">
                <img className="w-3 h-3.5" src="./img/IMG_20230118_224815.png" />
                <span className="ml-2">3 Hours</span>
              </div>
            </div>
          </div>

          <h4 className="font-bold mt-12 pb-2 border-b  border-grey-600">Latest Recipies</h4>

          <div className="mt-8">
            {/* cards go here */}
          </div>

          <div className="flex justify-center">
            <div className="btn text-black">Load More</div>
          </div>

        </div>

      </main>

      {/* Player Footer */}
      <footer className="bg-black text-3xl text-white text-center border-t-2 border-gray-600 shadow-2xl fixed inset-x-0 bottom-0 p-1 grid grid-flow-col h-38 s sm:h-38 md:h-28 lg:h-24 grid grid-rows-2 md:grid-rows-1 ">
        <div className="rounded bg-gray-700 p-3  row-span-1">
          <div className="relative pt-1">
            <label htmlFor="customRange1" className="form-label">Example range</label>

            <div className="w-full bg-slate-900 h-1 mb-6 relative">
              <div className="h-1 w-full song_progress " style={{ width: "50%" }}>
                {/* bg-gradient-to-r from-Trv_Blue to-Trv_Purple */}
              </div>
              <input type="range" className=" form-range appearance-none w-full h-6 p-0 bg-transparent focus:outline-none focus:ring-0 focus:shadow-none" id="customRange1"
              />
            </div>
          </div>
        </div>
        <div className=" rounded bg-blue-500 p-2 row-span-1 h-16 md:hidden flex-row flex justify-around">
          <div className="bot_nav_item_active"><h1>1</h1>
            <p className="bot_nav_text">text</p></div>
          <div className="bot_nav_item"><h1>2</h1>
            <p className="bot_nav_text">text</p></div>
          <div className="bot_nav_item"><h1>3</h1>
            <p className="bot_nav_text">text</p></div>

        </div>

      </footer>


      <script src="/index2.js"></script>
    </div>
  );
}

export default App;
